Progress report

# Task assignment for milestone 2

## Main objective
We have the following works to be assigned:
* Front End: implement a user interface, which parses the user inputs into the independent variable $x \in \mathbb{R}^m$, represented by a list with length $m$, the function $f : \mathbb{R}^m \mapsto\mathbb{R}^n$, and construct $f$ using elementary function class. 
* Back End: implement the main skeleton of the program, its essential classes and methods. The program can compute the derivatives of a function $f$ given $x_0$. The core classes will be `AutoDiff(), ElementFunction(), DualNumber(), Interface()` and the core methods will be `Jacobian(), forward(), get_value(), set_value()`. 
* Test and Continuous Integration (CI): write pytest for each class and run the tests when new commits are pushed to the github.
* Documentation and Distribution: write documentations for each class, their methods, how to use them and update the package through pypi as the project progresses.

## Assignment sheet
We tentatively assign the implementation tasks to each team member as follows:

**Peter Wu:** 

* Implement parts of the `DualNumber()` class with some documentation and create examples for `get_value()` and `set_value()`.

**Sophia Yang:** 

* Provide a requirements file for the package so other developers are able to install the necessary dependencies.
* Write the *installation* part in the documentation, for example, the creation of a virtual environment or some other kind of manual installation.

**Menghang (David) Wang:** 

* Implement `AutoDiff()`, `Jacobian()` and `ElementFunction()` class and implement the `forward` method. Write docstring for the corresponding class and methods.

**Ziqing Luo:** 

* Write test for `ElementFunction()` class with some documentation.
* Help write the *installation* part in the documentation.

**Yingzi (Vivian)  Wei:** 

* Write test for `DualNumber()` class with some documentation.
* Implement parts of the`Interface()` class with documentation.

# Progress for milestone 1
We describe the progress of each team member below:

**Peter Wu:** 

* Wrote the first draft for the *Introduction*.
* Wrote the first draft for the *Background* section with several hand-drawn tables and images.
* Respond to feedback 1 by creating the forward mode diagram in Google Drawings.
* Consult with the team of the implementations of `DualNumber()`.

**Sophia Yang:** 

* Wrote the the first draft for the *Software Organization* and *Licensing* sections.
* Respond to feedback 1 by adding a latex vertion of the forward trace table.

**Menghang (David) Wang:** 

* Rewrite the *Introduction* and modify the *Background* section. 
* Respond to feedback 2 by illustrating the variables $x,y$ appeared in the *How to use* section. 
* Respond to feedback 4 by rewriting the implementation section with detailed descriptions of each class object, pseudo-code for each class, expected user inputs and outputs, and the expected behavior of each class.

**Ziqing Luo:**  

* Wrote the first draft for the *Implementation* section

**Yingzi Wei:**  

* Wrote the first draft for the *Background* section
