Package name: AutoDiff


# Introduction

Differentiation is a critical component of modern computation. Ranging from the calculation the velocity fields of a dynamical equation to the back propagation when training neural networks, we need a robust and accurate algorithm to calculate the derivative.

This project will implement a Python package for automatic differentiation. The program will compute a value, and then automatically construct a procedure to evaluate the derivative of that value. Given a function of possibly several variables, the program can automate the calculation of its derivative. Automatic differentiation decomposes a large and complex problem into smaller sub-problems including elementary operations such as addition, subtraction, multiplication, division and elementary functions such as square root, exponential, and trigonometric functions. Furthermore, after decomposing the problem into more manageable chunks automatic differentiation repeatedly uses the chain rule to compute the derivative accurately to machine precision.

The significance of an automatic differentiation algorithm comes from its capability of calculating higher order derivatives, where numerical differentiation has problems of producing large and unstable numerical errors and high computational cost, and symbolic differentiation becomes extremely inefficient and produces redundant expressions as the function complexity increases. Therefore, developing an efficient, accurate, and robust program to compute derivative is crucial for the advancement of scientific computing. 

# Background

There are three major ways to compute the derivative of a function: numerical differentiation, symbolic differentiation, automatic differentiation. Numerical differentiation estimates the derivative of a function using finite difference approximation of the function at different points. Symbolic differentiation finds the derivative of a given formula with respect to a specified variable and output a new formula through manipulation of the mathematical expressions. Automatic differentiation is a set of techniques to evaluate the derivative of a function specified by a computer program [https://en.wikipedia.org/wiki/Automatic_differentiation].

Automatic differentiation (AD) is partly symbolic and partly numerical differentiation. It provides numerical values of derivatives, as opposed to derivative expressions; it does so by using symbolic rules of differentiation, but keeping track of derivative values as opposed to the resulting expressions. In comparison, pure numerical differentiation is the finite difference approximation of derivatives using values of the original function evaluated at some sample points.  Unlike traditional numerical differentiation that has problems of accuracy due to round-off and truncation errors, automatic differentiation is as accurate as symbolic differentiation with only a constant factor of overhead and support for control flow.


## Chain Rule

At the core of automatic differentiation is the chain rule. Suppose we are given the function $f(g(x))$. The derivative of this function with respect to $x$ is equal to $f’g(x) * g’(x)$. As an example, suppose we are given the function $\cos(9x^2-7x)$. The derivative with respect to $x$ of this expression is equal to $\sin(9x^2-7x) * (18x-7)$. In this case, we used $f(x)=\cos(x)$ and $g(x)=9x^2-7x$. At its core, all of automatic differentiation will be using this idea over and over again. The main challenge is to keep track of what variables are involved and which variable we are trying to differentiate with respect to.

## Elementary Functions

Any complex function is simply the combination of a lot of smaller elementary functions combined in some way. Examples of elementary functions include exponentiation, trigonometric functions(sine, cosine, tangent, etc.), square roots, and logs. These are all differentiable functions which we will be able to apply the chain rule to. 

## Graph Structure of Computation

Suppose we have the function: $f(x, y) = \cos(y) + \exp(9x)$ at the point $(1, 2).$

We draw out the computational graph for this problem.

![Graph Sketch](./images/milestone1_diagram.png)

The top chart is the forward graph of the problem. If we trace through this problem, we have y where we perform one elementary operation on it and obtain $a_1=\cos(y)$. On the bottom, we have x where we perform first one elementary operation on it and obtain $b_1=9x$ and then another elementary operation on it and obtain $b_2=\exp(9x)$. We combine the values we get above and obtain $f(x,y)=a_1+b_2$.

Below is the forward trace table with the derivatives:

|Trace| Elementary Operation|Numeric Value|Derivative ($\nabla x$)|$$\nabla x$$| Derivative ($\nabla y$)|$$\nabla y$$|
|----------------|-------------------------------|-----------------------------|---|---|---|---|
|$$x$$|$$1$$|$$1$$|$$1$$|$$1$$|$$0$$|$$0$$|
|$$b_1$$|$$9x$$|$$9$$|$$9$$|$$9$$|$$0$$|$$0$$|
|$$b_2$$|$$e^{b_1}$$|$$e^9$$|$$e^{b_1}D_p(b_1)$$|$$e^9(9)$$|$$0$$|$$0$$|
|$$y$$|$$1$$|$$2$$|$$0$$|$$0$$|$$1$$|$$1$$|
|$$a_1$$|$$\cos(y)$$|$$\cos(2)$$|$$0$$|$$0$$|$$\sin(y)$$|$$\sin(2)$$|
|$$f(x,y)$$|$$b_2+a_1$$|$$e^9+\cos(2)$$|$$e^{b_1}D_p(b_1)+0$$|$$e^9(9)$$|$$0+\sin(y)$$|$$\sin(2)$$|

The bottom graph in the previous photo is the reverse graph. We reverse the directions of the arrows and use the chain rule to calculate the derivatives. In the previous photo, we work out the example using the chain rule to calculate the derivative of $df/dx$.

To find the derivative of $f(x,y)$ with respect to $b_1$ for example, we would write:

$df(x,y)/d(b_1) = df(x,y)/d(b_2) * d(b_2)/d(b_1)$

To find the derivative of $f(x,y)$ with respect to $x$ for example, we would write:

$df(x,y)/dx = df(x,y)/d(b_2) * d(b_2)/d(b_1) * d(b_1)/(dx) = df(x,y)/dx$

To find the derivative of $f(x,y)$ with respect to $y$ for example, we would write:

$df(x,y)/dy = df(x,y)/d(a_1) * d(a_1)/d(y)$

In working out the forward pass, we would use the reverse graph combined with the chain rule to find the derivatives at all the nodes in the graph.

# How to Use `AutoDiff`

How do you envision that a user will interact with your package? What should they import? How can they instantiate AD objects?
This package of “AutoDiff” is distributed via PyPI (https://pypi.org/). The users can use it by pip install:
```
pip install AutoDiff
import AutoDiff as ad
```
One can initialize a variable with a dictionary input:
`var = {‘x’: 1, ‘y’: 2}`, where $x$ and $y$ are the names of the variable, and 1 and 2 are the values of the corresponding variable. 
And initialize a function object with an input of list as a `Function()` class object:
```
f = Function([2x+5y])
g = Function([2x+5y, ad.exp(x)+ad.sin(y)])
```
One can initialize a forward automatic differential object:
`ad.Forward(f, var)`
Similarly, a reverse automatic differential object:
`ad.Reverse(f, var)`

# Software Organization
- What will the directory structure look like?
![Structure Tree](./images/structure_tree.png)

- What modules do you plan on including? What is their basic functionality?
The main module is AutoDiff.py, which includes all classes and methods in the AutoDiff library. There are also other directories, .github/workflows which includes the workflows, tests which includes unit tests, and docs, which includes documentation. 

- Where will your test suite live?
Our test suite will live in a subdirectory called “.github/workflows.” It will be executed via GitHub actions (https://github.com/features/actions). Both coverage.yml and test.yml have been set up in the README.md file.

- How will you distribute your package (e.g. PyPI with PEP517/518 or simply setuptools)?
This package will be distributed via PyPI, which is the Python Package Index.

- Other considerations?
The package “AutoDiff” will depend on the package “NumPy.” 

# Implementation
**What classes do you need and what will you implement first?**
	
We will implement the following classes for the automatic differentiation package: 
- `DualNumber()`: it contains one real part and one dual part. The real part stores the value of any variable $v_j$, while the dual part stores the value of its direction derivative $D_p v_j$. This is the most fundamental unit in the computational graph, and thus it will be implemented first.
- `ComputationGraph()`: it tells how a function $f$ decomposes into elementary operations between variables $v_j$. Thus, it can be used to calculate the primal trace and tangent trace for any function $f$.
- `Derivative()`: it computes $n \times m$ Jacobian matrices for any given function $f(x_1,x_2,...,x_m):\mathbb{R}^m\mapsto\mathbb{R}^n$ with given values of $[x_1,x_2,...,x_m]$ using the computational graph.
- `AutoDiff()`: it is the main class that contains forward and reverse mode for automatic differentiation. It will be implemented last.
- `ElementFunction()`: a class that contains all the elementary functions, such as sin, cos, exp, log, tanh, sigmoid, relu, etc. The class will be used to construct the function $f$.

**What are the core data structures? How will you incorporate dual numbers?**

The core data structures would be the computational graph, which represents the elementary operations in a function. The computational graph will contains nodes and edges. Each node represents a variable, which is a `DualNumber()` object and each edge represents the elementary operations including actions from elementary functions. 

The user’s inputs to the Automatic Differentiation are as follows:
  1. __A vector of variables__: A dictionary where the key indicates the variable name and the value stores its value. For example, `var = {‘x1’: 1, ‘x2’: 2, ‘x3’: 8}`, where $x_1, x_2$ and $x_3$ are user-defined variable names and 1, 2 and 8 are corresponding values.
  2. __A vector of functions__: A function or a vector of $n$ functions, where each functions take an input vector as $(x_1,x_2,...,x_m)$

Then the `AutoDiff()` class will take variables and functions as inputs and then compute the value of functions and derivatives using `ComputationGraph()`, `DualNumber()`, and `Derivative()`. 

**What method and name attributes will your classes have?**
	
- `DualNumber()` 
  - ```
	Class DualNumber:
	def __init__(self, real):
		self.real = real
		self.dual = 1.0
	def __add__(self, other):
		pass
	def __sub__(self, other):
		pass
	def __mul__(self, other):
		pass
	def __truediv__(self, other):
		pass

- `ComputationGraph()` 
  - ```
	Class ComputationGraph:
	'''	construct a tree structure which breaks functions into edges (elementary operations) and nodes variables)
	'''
	def __init__(self, variables, functions):
		self.variables = variables
		self.functions = functions
	def forward(self, var):
		pass
	def backward(self, var):
		pass
	def get_primal_trace(self, node):
		pass
	def get_tangent_trace(self, node):
		pass

- `Derivative()` 
  - ```
	Class Derivative:
	def __init__(self, x, f):
		self.x = x
		self.f = f
	def jacobian(self):
		pass
- `AutoDiff()` 
  - ```
	Class AutoDiff:
	def __init__(self, x, f):
		self.x = x
		self.f = f
	def jacobian(self):
		pass

	
Elementary Functions: Mathematically similar to the elementary functions that we have for real numbers but we recreate them so that they adapt to Dual Number Class objects:

	- exp()
	- sin()
	- cos()
	- log()
	- power()
	- sqrt()

- Will you need some graph class to resemble the computational graph in forward mode or maybe later for reverse mode? Note that in milestone 2 you propose an extension for your project, an example could be reverse mode.
	- Yes, developing graph classes could be our extension for the project.

- Think about how your basic operator overloading template should look like. How will you deal with elementary functions like sin, sqrt, log, and exp(and many others)?
	- Elementary functions like sin, cos, sqrt, log, and exp will be recreated specifically for Dual Number class. But of course within each function we will make use of the NumPy package. 

- How do you want to handle cases for f: R^m -> R or later f: R^m -> R^n? Would it make sense to design a high-level function object to model arbitrary functions f? You could think further and possibly plan for a grad() method or similar in a class that models f, since computing the gradient (or Jacobian) is an operation that is often required.
	- For higher-dimensional input, we plan to handle these cases by extending the function to handle a list of input. Thus, no additional function is necessary. 

- Do you want/need to depend on other libraries? (e.g. NumPy)
	- This package “AutoDiff” will depend on NumPy for calculations. 

# Licensing

We used the MIT license because it is much more permissive than the GNU GPLv3 and allows companies to make modifications to open source code that can be kept closed source. The MIT license has a high license compatibility and is one of the most popular licenses on GitHub.

# Feedback

## milestone 1
1. **Background:** I like your mathematical details. But please not involve the hand-drawn pictures which are not professional (-0.25)

We will delete the hand-drawn pictures and replace with formal equations. 

2. **How to use:** The instantiation of variables is not clear and solid. Where does the x, y, z in f and g equation come from? (-0.25)

$x$, $y$ in function $f$ and $g$ are user-specified variable names, which serve as the key in the dictionary. Each variable name has its corresponding values. For instance, in our document, the variable is `var = {‘x’: 1, ‘y’: 2}` and it means that the user create a variable of 2 dimensional and it calls the 1st dimension $x$ and 2nd dimension $y$. We will make it more clear in the documentation.

1. **Software organization:** The picture showing the structure of different folders is great.- You want to put all the classes in on e python file. Is it a good way to do so? (-0.25)

DualNumber Class and derivative Class will be on different python files. Under the directory AutoDiff, there will also be a __init__.py file which will import all the classes and methods in the AutoDiff library.

4. **Implementation (explicit design considerations):** How will the computational graph class will be used?- How is the AutomaticDiff class designed? How will it be related to Dual Number class? (-0.25)

The computational graph will be use to construct the derivative class, where the forward mode and reverse mode will be implemented. The dual part of the dual number class will be used to store the derivative value, while the real part will store the function value. 


