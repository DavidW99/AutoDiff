# Introduction
Differentiation is a critical component of modern computation. Ranging from the calculation the velocity fields of a dynamical equation to the back propagation when training neural networks, we need a robust and accurate algorithm to calculate the derivative.

This project will implement a Python package for automatic differentiation. The program will compute a value, and then automatically construct a procedure to evaluate the derivative of that value. Given a function of possibly several variables, the program can automate the calculation of its derivative. Automatic differentiation decomposes a large and complex problem into smaller sub-problems including elementary operations such as addition, subtraction, multiplication, division and elementary functions such as square root, exponential, and trigonometric functions. Furthermore, after decomposing the problem into more manageable chunks automatic differentiation repeatedly uses the chain rule to compute the derivative accurately to machine precision.

The significance of an automatic differentiation algorithm comes from its capability of calculating higher order derivatives, where numerical differentiation has problems of producing large and unstable numerical errors and high computational cost, and symbolic differentiation becomes extremely inefficient and produces redundant expressions as the function complexity increases. Therefore, developing an efficient, accurate, and robust program to compute derivative is crucial for the advancement of scientific computing. 

# Background
There are three major ways to compute the derivative of a function: numerical differentiation, symbolic differentiation, automatic differentiation. Numerical differentiation estimates the derivative of a function using finite difference approximation of the function at different points. Symbolic differentiation finds the derivative of a given formula with respect to a specified variable and output a new formula through manipulation of the mathematical expressions. [Automatic differentiation](https://en.wikipedia.org/wiki/Automatic_differentiation) is a set of techniques to evaluate the derivative of a function specified by a computer program.

Automatic differentiation (AD) is partly symbolic and partly numerical differentiation. It provides numerical values of derivatives, as opposed to derivative expressions; it does so by using symbolic rules of differentiation, but keeping track of derivative values as opposed to the resulting expressions. In comparison, pure numerical differentiation is the finite difference approximation of derivatives using values of the original function evaluated at some sample points.  Unlike traditional numerical differentiation that has problems of accuracy due to round-off and truncation errors, automatic differentiation is as accurate as symbolic differentiation with only a constant factor of overhead and support for control flow.

# How to use the package

## Installation
To install the package, a user shall have a Python version >= 3.7 and `numpy` >= 1.20.3 as the basic requirement. This package is Operating System independent. 

This package is released on TestPyPI [https://test.pypi.org] under the name "cs107-AutoDiff." The latest version is 0.0.2.

One can install the package by simply copying the following line in a Terminal:

```
python3 -m pip install --index-url https://test.pypi.org/simple/ --no-deps cs107-AutoDiff
```
which will create a "AutoDiff" folder and a "cs107_autodiff-0.0.2.dist-info" folder in the directory of the user's default Python packages.

To import the package in Python, type the following lines:

```python:
from AutoDiff.AutoDiff import AutoDiff as AD
from AutoDiff.ElementFunction import *
from AutoDiff.DualNumber import DualNumber
import numpy as np
```

## A basic user demo

A user can create an `AutoDiff` object with a given mathematical function:

```python:
>>> ### 1. Define your function
>>> function = lambda x: sin(x) + 3*cos(x)
>>> ### 2. Create an AutoDiff object
>>> myAD = AD(function)
>>> print(myAD) 
AutoDiff contains a list of 1 function(s)
```

And evaluate the function and its derivative with given variable values:

```python:
>>> ### 3. Create a list of x where we want to evaluate the function and its derivative
>>> x = [np.pi/2, 3, 5]
>>> ### 4. Get the function value and gradient by inputting x
>>> print(myAD(x)) 
[1.0000000000000002, -2.828857481741469, -0.10793771827345966]
>>> print(myAD.grad(x)) 
[-3.0, -1.413352520780047, 3.1604350094526414]
```

Now, we can check the answer with the analytical solution:

```python:
>>> grad_function = lambda x: cos(x) - 3*sin(x)
>>> print([grad_function(xi) for xi in x]) 
[-3.0, -1.413352520780047, 3.1604350094526414]
```

## Use through git clone 
You can also use the package without installing it by cloning the repository from GitHub. Pasting the following line into your terminal:
  
  ```
  git clone git@code.harvard.edu:CS107/team41.git
  ```
Then, you may find the there is a `usage/` folder in the repository. You can start with `usage.py` to find your own use case for the automatic differentiation. 

Still, you need a Python version >= 3.7 and `numpy` >= 1.20.3 as the basic requirement.

# Software Organization
## High-level overview of how the software is organized:
  ![Structure Tree](./images/structure_tree2.png)
  
There are 3 modules in this package: 
- `AutoDiff.py`: This module includes an AutoDiff class which allows the user to initialize an AutoDiff object **f** with a function $f(x_1,x_2,...,x_m):\mathbb{R}^m\mapsto\mathbb{R}^n$. The user then can use this object to calculate the value and derivative of that function on the input with given values of $[x_1,x_2,...,x_m]$ . 
   
- `DualNumber.py`: This module includes a DualNumber class, which allows the user to define a Dual Number object. 
   
- `ElementFunction.py`: This module contains functions such as **sin()**, **cos()**, **tan()**, **exp()** and **log()** that can be applied to Dual Number objects. 

## Where do tests live? How are they run? How are they integrated?
  - Our test suite will live in a directory called `tests/`. The test suite is run with pytest and will run automatically through the CI setup configured in the `test.yml` file stored in the subdirectory called `.github/workflows`. We also have code coverage workflow set up in the `coverage.yml` file. The test coverage will pass if the coverage satisfies 90% or more and fail otherwise. 
  

## How to install the package?

Please refer to the [installation](#installation) under "How to use the package".
  
# Implementation details

There are three files that we use for our implementation: **AutoDiff.py**, **DualNumber.py**, and **ElementFunction.py**. We discuss each in detail:

- **AutoDiff.py**
  - The main functions of this class are:
    - `__call__` evaluates the function we pass in on a vector of inputs
    - `convert_to_dual` converts a list of ints or floats into a list of DualNumber objects
    - `grad`  evaluates the gradient of a function on a vector of inputs
    
- **DualNumber.py**
  - A DualNumber is a class with two attributes: **real (int/float)** and **dual (int/float)**. 
  - The main functions of this class are:
    - `check_type_convert` which converts ints and floats to a DualNumber with the same real part but with $0$ as the dual part
    - `__add__` and `__radd__` which enable DualNumber addition
    - `__sub__` and `__rsub__` which enable DualNumber subtraction
    - `__mul__` and `__rmul__` which enable DualNumber multiplication
    - `__truediv__` and `__rtruediv__` which enable DualNumber division
    - `__pow__` and `__rpow__` which enable DualNumber exponentation
    - `__eq__` and `__ne__` which compares equality of two DualNumbers
    - `__lt__` and `__le__` which compares if a DualNumber is less or less than or equal to another DualNumber
    - `__gt__` and `__ge__` which compares if a DualNumber is less or less than or equal to another DualNumber
- **ElementFunction.py**
  - The main functions of this class perform elementary operations on a list of DualNumbers or ints/floats:
    - `sin` is able to take in a list of ints/floats/DualNumbers and perform the `sin()` operation on each
    - `cos` is able to take in a list of ints/floats/DualNumbers and perform the `cos()` operation on each   
    - `tan` is able to take in a list of ints/floats/DualNumbers and perform the `tan()` operation on each
    - `exp` is able to take in a list of ints/floats/DualNumbers and perform the `exp()` operation on each
    - `log` is able to take in a list of ints/floats/DualNumbers and perform the `log()` operation on each

What we have implemented so far is to perform the automatic differentation for scalars. We plan to implement in the future the case where we have more than one variable, and we will have to deal with partial derivatives. This may involve setting the `dual` attribute of the DualNumber equal to something like a `numpy` array. For instance, if we have $x_1$ and $x_2$, we will have to have two passes of the seed vector $[1, 0]$ and $[0, 1]$ where the first vector is with respect to $x_1$ and the second with respect to $x_2$.

<!-- 
[Peter] David, I commented this part out. But below is the expectations for this part for your reference.

- Description of current implementation. This section goes deeper than the high level software organization section.
  - Try to think about the following:
    - Core data structures
    - Core classes
    - Important attributes
    - External dependencies
    - Elementary functions
  - This is similar to what you did for Milestone 1, but now you've actually implemented it.
  - What aspects have you not implemented yet? What else do you plan on implementing? -->
  
# Future features
* Advanced Functionalities: add new functionalities to the package, such as handling multiple datasets, different types of inputs, computation speedup, expanding the types of the elementary functions etc. 
* Neural Network Class: implement a neural network class that can be used to setup a neural network model.
* Package Tutorial: write a Google Colab tutorial with some examples which help people learn to use this package faster. It will include content on how to install the package, how to use the functionalities, how to do back propagation and gradient descent in a neural network. For the final step, we will include some activation functions into the elementary function class. 
