# Checklist for milestone 2
## To do:
* coverage.yml (lecture 15)
* milestone2.md
## Package requirement
  * whether package can be downloaded from GitHub and installed
## Implementation requirement
  * Should we write a txt file for the dependencies?
  * How should we let user make inputs?
    * Current usage demo:
      * User defines its function: eg. `f lambda = lambda x: sin(x) + 3*cos(x)`
      * User creates an AutoDiff object: eg. `f1 = AutoDiff(f)`, passing the function `f` as an argument
      * User provides a list of values (or a single scalar) for the independent variables: eg. `x_vec = [1,2,3]`
      * User can get the fuction value by calling `f1(x_vec)`, which returns a list of function values at `x_vec`
      * User can get the derivative value by calling `f1.grad(x_vec)`, which returns a list of derivative values at `x_vec`
    * eg. building an interactive interface (probably not)
        
            Please input your variable with its value: x = 1 
            Please input your function: f = x**2
            Here is df(x)/dx @ x=1: 2
    * Is there a better way than reading in the function as a string and convert to mathematical operation and functions?
  * What the package should do:
    * Import a AutoDiff class from the package and make an object.
    * Calculate a Jacobian for a root-finding algorithm using Newton's method
    * Access the Jacobian
## Function requirement
  * addition, multiplication, subtraction, division, power, negation (DualNumber Class)
  * exponential, trig functions (ElementFunction Class)
## Test
  * tests on DualNumber, ElementFunction, AutoDiff.
    * tests on AutoDiff: Should we do testing using formula expression or actual value, what are the industry standards?
  * integrate test.yml with CI
  * integrate coverage.yml with CI 
    * https://www.atlassian.com/continuous-delivery/software-testing/code-coverage
## Distribution
  * Hands-on tutorial (Google Colab or Jupyter Notebook)
    * Colab will not generate a binary file each time we update the file
    * Jupyter Notebook will be sth local
  * Should the documentation be on a PyPi website or the docs folder in the GitHub repo?