import sys
sys.path.append('../')
from AutoDiff.AutoDiff import AutoDiff as AD
from AutoDiff.feature import grad_descent
from AutoDiff.ElementFunction import *
import numpy as np

""" gradient descent """

## demo of 1D function
def demo_1D():
    f = lambda x: (x-1)**2
    x0 = 4
    x = grad_descent(f, x0, alpha=1e-3, max_iter=int(1e6), verbose=True)
    print(f"x={x:.3f} gives the minimum value of f(x)={f(x):.3f}")

def demo_1D_quartic():
    f = lambda x: -10*x**2 + x**4 - x 
    x0 = 4
    x = grad_descent(f, x0, alpha=1e-5, verbose=True)
    print(f"x={x:.3f} gives the minimum value of f(x)={f(x):.3f}")

def demo_2D():
    f = lambda x, y: (sin(x-0.1))**2+(cos(y))**2
    # create an AutoDiff object to get function value 
    ADf = AD(f)
    x0 = np.array([0.5, 0.2])
    x = grad_descent(f, x0, alpha=1e-4, converge_threshold=1e-8, verbose=True)
    print(f"x={x} gives the minimum value of f(x)={ADf(x):.3f}")


## run 
#demo_1D()
#demo_1D_quartic()
demo_2D()
